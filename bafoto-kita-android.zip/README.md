# BAFOTO KITA — proyek APK Android

Aplikasi ini membungkus `index.html` (di `app/src/main/assets/`) dalam WebView. Data tersimpan di penyimpanan aplikasi; gunakan **Pengaturan → Ekspor cadangan** (tersimpan di folder Download) sebelum menghapus aplikasi.

## Cara 1 — Android Studio
1. Ekstrak zip, buka foldernya di Android Studio (File → Open), tunggu sinkronisasi Gradle selesai.
2. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Hasil: `app/build/outputs/apk/debug/app-debug.apk`. Kirim ke HP dan pasang (izinkan "pasang dari sumber tidak dikenal").
Jika Studio menanyakan versi Gradle, pilih Gradle 8.7 atau yang disarankan.

## Cara 2 — Tanpa Android Studio (GitHub)
1. Buat repositori GitHub baru, unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions → Build APK → Run workflow**.
3. Setelah selesai, unduh `BAFOTO-KITA-apk` dari bagian Artifacts, ekstrak, dan pasang `app-debug.apk`.

Minimal Android 10. Perlu internet hanya untuk pencarian contoh foto dari web.
